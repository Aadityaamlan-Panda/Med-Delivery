from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_socketio import SocketIO, emit
from flask_migrate import Migrate
import time

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///donations.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
socketio = SocketIO(app)
migrate = Migrate(app, db)  # Initialize Flask-Migrate

# Models
class Donation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    donor_name = db.Column(db.String(100), nullable=False)
    medicine_name = db.Column(db.String(200), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    contact_info = db.Column(db.String(100), nullable=False)
    delivery_status = db.Column(db.String(100), default="Pending Pickup")  # Delivery status field
    
    # Timestamp to track when the donation is created
    created_at = db.Column(db.DateTime, default=db.func.now())

    def __repr__(self):
        return f"<Donation {self.medicine_name} by {self.donor_name}>"

class DeliveryCompany(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    contact_info = db.Column(db.String(100), nullable=False)

class NGO(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    contact_info = db.Column(db.String(100), nullable=False)

# Simulate delivery status updates (Using SocketIO)
@socketio.on('connect')
def handle_connect():
    print("Client connected")

# Simulate delivery status updates
def simulate_delivery(donation_id):
    stages = ["Pending Pickup", "Picked Up", "In Transit", "Delivered"]
    donation = Donation.query.get(donation_id)
    if donation:
        for stage in stages:
            time.sleep(5)  # Simulate delay
            donation.delivery_status = stage
            db.session.commit()
            print(f"Emitting status update: {donation_id} - {stage}")
            socketio.emit('status_update', {'id': donation_id, 'status': stage}, broadcast=True)

    else:
        print(f"Donation {donation_id} not found")

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/donate', methods=['POST'])
def donate():
    donor_name = request.form.get('donor_name')
    medicine_name = request.form.get('medicine_name')
    quantity = request.form.get('quantity')
    contact_info = request.form.get('contact_info')

    new_donation = Donation(
        donor_name=donor_name,
        medicine_name=medicine_name,
        quantity=quantity,
        contact_info=contact_info
    )
    db.session.add(new_donation)
    db.session.commit()

    # Start delivery simulation in a separate thread
    socketio.start_background_task(target=simulate_delivery, donation_id=new_donation.id)

    return jsonify({"message": "Donation successful!", "id": new_donation.id}), 200

@app.route('/donations')
def donations():
    donations_list = Donation.query.all()
    return render_template('donations.html', donations=donations_list)

@app.route('/delivery/<int:donation_id>')
def track_delivery(donation_id):
    donation = Donation.query.get_or_404(donation_id)
    return render_template('delivery_status.html', donation=donation)

# Main
if __name__ == "__main__":
    with app.app_context():
        db.create_all()  # This will create the tables if they don't exist
    socketio.run(app, debug=True)
